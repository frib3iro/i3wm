#!/usr/bin/env bash

clear

echo "Intalando o devour"
sleep 2s

yay -S devour
cp /usr/share/doc/ranger/config/rifle.conf /home/fabio/.config/ranger

# Alias no .bashrc
# alias feh='devour feh'
# alias sxiv='devour sxiv'
# alias mpv='devour mpv'
