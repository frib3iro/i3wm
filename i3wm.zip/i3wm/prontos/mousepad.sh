#!/usr/bin/env bash

clear

echo "Clonando o repositório do tema dracula do mousepad"
sleep 2s
sudo pacman -S mousepad --noconfirm
git clone https://github.com/dracula/mousepad.git && cd mousepad
mkdir -p "$HOME/.local/share/gtksourceview-3.0/styles"
cp dracula.xml $HOME/.local/share/gtksourceview-4/styles
