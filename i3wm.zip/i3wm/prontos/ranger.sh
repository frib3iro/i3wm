#!/usr/bin/env bash

clear

echo "Instalando e configurando o ranger para exibir imagens"
sleep 2s
pacman -S ranger ueberzug --noconfirm
mkdir /etc/ranger
touch /etc/ranger/rc.conf
cat >> '/etc/ranger/rc.conf' << EOF
set preview_images true
set preview_images_method ueberzug
EOF

.config/ranger
wget https://raw.githubusercontent.com/ranger/ranger/master/ranger/config/rc.conf
set preview_images true
set preview_images_method ueberzug
