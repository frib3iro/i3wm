#!/usr/bin/env bash

clear 

echo "Instalando o yay"
git clone https://aur.archlinux.org/yay.git
cd yay
makepkg -si --noconfirm
rm -rf go yay
