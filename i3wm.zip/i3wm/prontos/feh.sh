#!/usr/bin/env bash

clear

echo "Instalando e configurando o feh"
sleep 2s
sudo pacman -S feh --noconfirm
cp /home/fabio/Imagens/wallpapers/* /usr/share/backgrounds/archlinux/
feh --bg-fill  /usr/share/backgrounds/archlinux/000.wallpaper.jpg
