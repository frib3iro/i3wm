#!/usr/bin/env bash

clear

echo "Configurando o arquivo dmenu_run..."
sleep 1s
sudo sed -i '/#!\/bin\/sh/a LANG="pt_BR.UTF-8"' dmenu_run
