#/usr/bin/env bash

clear

echo "Instalando rofi e aplicando o tema dracula"
sleep 2s
sudo pacman -S rofi
git clone https://github.com/dracula/rofi
cp rofi/theme/config1.rasi ~/.config/rofi/config.rasi

### Executar estes comandos para configurar o rofi

# rofi
# rofi -show drun
# rofi-theme-selector
# rofi -show drun -show-icons  

### Adicionar esta linha ao config do i3wm

# bindsym $mod+d exec --no-startup-id rofi -show drun -show-icons
