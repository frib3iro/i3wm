#!/usr/bin/env bash

clear

echo "Iniciando serviços"
sleep 2s
systemctl enable bluetooth.service
systemctl enable cups.service
systemctl enable lightdm.service
