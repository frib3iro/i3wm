#!/usr/bin/env bash

clear

echo "Lista de fontes para instalar com o pacman"
sleep 2s
sudo pacman -S ttf-monaco ttf-droid ttf-font-awesome ttf-inconsolata ttf-opensans --noconfirm

echo "Lista de fontes para instalar com o yay"
sleep 2s
yay -S ttf-ms-fonts ttf-ubuntu-font-family consolas-font --noconfirm

echo "Executando fc-cache -fv para construir o cache de fontes"
sleep 2s
sudo fc-cache -fv
