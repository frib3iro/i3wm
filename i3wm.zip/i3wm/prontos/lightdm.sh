#!/usr/bin/env bash

clear

echo "Instalando o lightdm"
sleep 2s
sudo pacman -S lightdm lightdm-gtk-greeter lightdm-slick-greeter --noconfirm
sed -i 's/#greeter-session=example-gtk-gnome/greeter-session=lightdm-gtk-greeter/' /etc/lightdm/lightdm.conf''

