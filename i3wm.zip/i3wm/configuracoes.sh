#!/usr/bin/env bash

clear

echo "Colorindo o pacman"
sleep 2s
sed -i 's/#Color/Color/' /etc/pacman.conf

echo "Baixando repositórios do Github"
sleep 2s
git clone https://github.com/frib3iro/github
mv github/*.sh .
./git.sh
./github.sh
rm -rf git.sh github.sh github

echo "Configurando a tela de bloqueio"
sleep 2s
mkdir -p /home/fabio/.config/i3blocks/scripts
cd /home/fabio/.config/i3blocks/scripts
wget https://raw.githubusercontent.com/Raymo111/i3lock-color/master/examples/lock.sh
# Colocar a linha abaixo no arquivo de configuraçao do i3
# bindsym $mod+x exec /home/fabio/.config/i3blocks/scripts/lock.sh

# echo "xrander para resolução de tela"
# xrandr --output Virtual-1 --mode 1360x768

# echo "brightnessctl para brilho de tela"
# pacman -Qi brightnessctl
# pacman -S brightnessctl
# bindsym XF86MonBrightnessUp exec brightnessctl -c backlight set +1% 
# bindsym XF86MonBrightnessDown exec brightnessctl -c backlight set 1%-


