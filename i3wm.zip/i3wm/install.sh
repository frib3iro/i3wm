#!/usr/bin/env bash

clear

echo "Lista de pacotes para instalar com o pacman"
sleep 2s

sudo pacman -S --noconfirm

aircrack-ng
arc-gtk-theme
archlinux-wallpaper
arc-icon-
arc-icon-theme
bash-completion
bluez
bluez-utils
bully
capitaine-cursors
cmatrix
cowpatty
cronie
cups
dmenu
dunst
fdupes
feh
ffmpegthumbnailer
file-roller
flameshot
font-manager
geany
geany-plugins
gvfs
gimp
gparted
gst-libav
gst-plugin-pipewire
gufw
hashcat
hcxdumptool
hcxtools
htop
i3blocks
i3-gaps
i3lock
i3status
libreoffice
libreoffice-fresh-pt-br
links
lollypop
lxappearance
man-pages-pt_br
mesa-demos
moc
mousepad
mplayer
neofetch
picom
playerctl
ranger
reaver
rofi
rsync
sxiv
tcpdump
termshark
theme
thunar
thunar-archive-plugin
tumbler
unrar
unzip
wifite
xclip
xcursor-vanilla-dmz
xcursor-vanilla-dmz-aa
xfce4-terminal
xorg-xsetroot
zathura 
zathura-pdf-mupdf 
zathura-djvu 
zathura-ps 
zathura-cb

echo "lista para instalar com yay"
sleep 2s

yay -S --noconfirm

4kvideodownloader
cava
crunch
debtap
downgrade
google-chrome
mintstick
mint-y-icons
onedriver
pyrit
spotify
timeshift
tumbler-extra-thumbnailers
xcursor-breeze
typora-free
